<?php

$con = mysqli_connect("localhost", "root", "123", "ecom_store");
